# Permissions and Licensing

The data owner has authorized research use and public release of the farm
records, including original animal IDs and recorded breeding labels.

Permission to publish is not automatically a specific standardized reuse
license. No Creative Commons, MIT or other license is asserted in this local
prepublication package. The data and code licenses must be selected by the
rights holder before a licensed repository release is published.

Repository-level scientific attribution is separate from hidden file
properties. Removing workbook authors or computer paths does not remove the
study's provenance, assign ownership to a different person or waive attribution.
